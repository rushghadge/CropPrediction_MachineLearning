<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "crop");
define("DB_PASSWORD", "crop");
define("DB_DATABASE", "crop");
?>
