<?php

    // include db handler
    
    
    require_once 'include/Config.php';

        // connecting to mysql
        $con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die(mysql_error());
        // selecting database
        mysql_select_db(DB_DATABASE) or die(mysql_error());

        
     
    $uid=$_REQUEST['id'];
    $blood_group=$_REQUEST['blood_group'];
     $country=$_REQUEST['country'];
 $state=$_REQUEST['state'];
  $district=$_REQUEST['district'];
   $city=$_REQUEST['city'];
    $mobile=$_REQUEST['mobile'];

    $flag['code']=0;

    if($r=mysql_query("insert into users_profile values('$id','$blood_group','$country','$state','$district','$city','$mobile',) ",$con))
    {
        $flag['code']=1;
        echo"hi";
    }

    print(json_encode($flag));
    mysql_close($con);
?>
