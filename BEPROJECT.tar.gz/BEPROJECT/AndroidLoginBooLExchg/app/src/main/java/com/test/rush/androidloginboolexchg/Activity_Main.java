package com.test.rush.androidloginboolexchg;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import android.content.Intent;

import helper.SQLiteHandler;
import helper.SessionManager;
import volley.AppController;
import volley.Config_URL;
import android.os.Bundle;
import android.support.design.widget.*;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import helper.SQLiteHandler;
import helper.SessionManager;
import volley.AppController;
import volley.Config_URL;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import volley.AppController;
import volley.Config_URL;
public class Activity_Main extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private static final String TAG = SQLiteHandler.class.getSimpleName();
    private TextView txtName,navname,navemail;
    private TextView txtEmail;
    private Button btnLogout,btnSearch;
public String uidran;
    private SQLiteHandler db;
    private SessionManager session;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    String emailC,uidC,name,email,em,uid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        Log.d(TAG, "Inside main oncreate " );

        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        txtName = (TextView) findViewById(R.id.name);
        txtEmail = (TextView) findViewById(R.id.email);
        navname = (TextView) findViewById(R.id.navName);
        navemail = (TextView) findViewById(R.id.navEmail);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        String em =  getIntent().getStringExtra("email");

        String uid =  getIntent().getStringExtra("uidrandomno");

//ADD SHARED PREF AND SAVE UID AND EMAIL OF LOGGED IN USER
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("Email",em);
        editor.putString("UID",uid);
        editor.apply();

        db = new SQLiteHandler(getApplicationContext());

        // session manager
        session = new SessionManager(getApplicationContext());

        if (!session.isLoggedIn()) {
            logoutUser();
        }

        // Fetching user details from sqlite
        HashMap<String, String> user = db.getUserDetails(uid);
        ////////////////////

        Log.d(TAG, "Fetching user from Sqlite: main_ac " + user.toString());
        String data;
        data=user.toString();
        if (data != null && !data.isEmpty() && !data.equals("null"))
        {
            Log.d(TAG, "data hull calling getUserDetails " );
//add code here to fetch data from mysql
           String id= getUserDetails(em);
            Log.d(TAG, "After calling getusrdetails String id- "+id );

        }

         name = user.get("name");
         email = user.get("email");
       // String uidrandom=
        // String email = em;
        // Displaying the user details on the screen
         emailC = preferences.getString("Email", "");
         uidC = preferences.getString("UID", "");
        txtName.setText(emailC);
        txtEmail.setText(uidC);
        //nav_user.setText(name);

       // navemail.setText(email);
        // Logout button click event
        btnLogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });



        // Search button Click Event
        btnSearch.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                Intent searchint = new Intent(getApplicationContext(),
                        Activity_Search.class);

                startActivity(searchint);
              //  finish();

            }

        }); //search
    } //oncreate



    /**
     * Logging out the user. Will set isLoggedIn flag to false in shared
     * preferences Clears the user data from sqlite users table
     * */
    private void logoutUser() {
        session.setLogin(false);

        // db.deleteUsers();

        // Launching the login activity
        Intent intent = new Intent(Activity_Main.this, Activity_Login.class);
        startActivity(intent);
        finish();
    }


    public String getUserDetails(final String email) {
        Log.d(TAG, "inside getUserDetails " );
        // Tag used to cancel the request
        String tag_string_req = "req_details";



        StringRequest strReq = new StringRequest(Request.Method.POST,
                Config_URL.URL_REGISTER, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "req_details Response: " + response.toString());
                // hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    JSONObject objectuser = jObj.getJSONObject("user");
                    String name = objectuser.getString("name");
                    String email = objectuser.getString("email");
                   // JSONObject uidranobj = jObj.getJSONObject("uid");
                    String uidran1 = jObj.getString("uid");
                    uidran=String.format("%s",uidran1);
                    Log.d(TAG, "uid" + uidran);
                    // Check for error node in json
                    if (!error) {
                        txtName.setText("N:"+uidran);
                        txtEmail.setText("E"+email);

                  //      txtName.setText(name);
                  //      txtEmail.setText(email);

                    } else {
                        // Error in login. Get the error message
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "GetUserDetails Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                // hideDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "getuserdetails");
                params.put("email", email);


                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
        return uidran;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
int flag;
        if (id == R.id.nav_profile) {

            checkifProfileExist(uidran);
//
        }

        else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    public void checkifProfileExist(String uidr){
        int flag;
        Log.d(TAG, "checkifProfileExist : " );
        // Tag used to cancel the request
        String tag_string_req = "req_toCheckUser";
        final String  uid = uidr;
        // pDialog.setMessage("Logging in ...");
        //showDialog();

        StringRequest strReq = new StringRequest(Method.POST,
                Config_URL.URL_REGISTER, new Response.Listener<String>() {
           // int flag;
            @Override
            public void onResponse(String response) {
                Log.d(TAG, "UserProfile Response: " + response.toString());
                //  hideDialog();


                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");

                    if (!error) {

                        String uidran2 = String.format("%s", uidran);
                        Intent intUsr = new Intent(getApplicationContext(), Activity_AfterProf_Saving.class);

                        intUsr.putExtra("uidrfromLogin", uidran2);
                        startActivity(intUsr);
                        finish();
                    } else {
               String em = getIntent().getStringExtra("email");

               String uidran2 = String.format("%s", uidran);
               Intent intUsr = new Intent(getApplicationContext(), UserProfile.class);
            intUsr.putExtra("uidrfromLogin", uidran2);
             startActivity(intUsr);
                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
            //return flag;
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
               // hideDialog();
            }
        }) {
         //   return flag;
            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "userProfileCheckIfExist");
                params.put("uid", uid);
                //  params.put("password", password);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
        //
        //int flag;
     //   int flag=0;
        //return 1;
    }


}