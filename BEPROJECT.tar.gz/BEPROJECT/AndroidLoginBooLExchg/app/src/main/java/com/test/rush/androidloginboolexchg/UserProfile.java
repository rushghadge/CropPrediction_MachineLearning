package com.test.rush.androidloginboolexchg;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
//import android.widget.TextView;
import android.widget.ArrayAdapter;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import helper.SQLiteHandler;
import helper.SessionManager;
import volley.AppController;
import volley.Config_URL;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import volley.AppController;
import volley.Config_URL;

public class UserProfile extends Activity {
   String uid,uidr;   //	uid
    String blood_group,country,state,district,city;
    String id;
    private ProgressDialog pDialog;
    String mobile;
    InputStream is=null;
    String result=null;
    String line=null;
    int code;
    String[] SPINNERLIST = {"A+", "A-", "B+", "B-","AB+","AB-","O+","O-"};
    private static final String TAG = UserProfile.class.getSimpleName();
    private Button btnToSaveUserProfile;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final String uidr= getIntent().getStringExtra("uidrfromLogin");


        setContentView(R.layout.activity_profile);
        final MaterialBetterSpinner spinrBldGrp=(MaterialBetterSpinner) findViewById(R.id.android_material_design_spinner);
        final EditText et_country=(EditText) findViewById(R.id.edtTxtCountry);
        final EditText et_state=(EditText) findViewById(R.id.edtTxtState);
        final EditText et_district=(EditText) findViewById(R.id.edtTxtDistrict);
        final EditText et_city=(EditText) findViewById(R.id.edtTxtCity);
        final EditText et_mobile=(EditText) findViewById(R.id.edtTxtMobile);

        // Progress dialog
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, SPINNERLIST);
        MaterialBetterSpinner materialDesignSpinner = (MaterialBetterSpinner)
                findViewById(R.id.android_material_design_spinner);
        materialDesignSpinner.setAdapter(arrayAdapter);
        btnToSaveUserProfile = (Button) findViewById(R.id.btnToSaveUserProfile);
      //  String em =  getIntent().getStringExtra("uidrandomno");//getIntent().getExtras().getString("email");
//final String uidr= getIntent().getStringExtra("uidrfromLogin");
        //btnToSaveUserProfile.setText(uidr);
//Log.d("test", "test");
        Log.d(TAG, "uid in usr prof " + uidr);

        btnToSaveUserProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                // uidr= getIntent().getStringExtra("uidrfromLogin");
                Log.d(TAG, "uid in onsave cliv=ck" + uidr);
                blood_group = spinrBldGrp.getText().toString();
                country = et_country.getText().toString();
                state = et_state.getText().toString();
                district= et_district.getText().toString();
                city= et_city.getText().toString();
               mobile = et_mobile.getText().toString();
//

                saveUserProfile(uidr,blood_group,country,state,district,city,mobile);

            }
        });



    }//oncreate
//

    private void saveUserProfile(final String uidr,final String blood_group,final String country,final String state,final String district,final String city,final String mobile) {
        // Tag used to cancel the request
        String tag_string_req = "save_prof";

        pDialog.setMessage("Updating Profile ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Config_URL.URL_REGISTER, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Save Prof Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    if (!error) {

                        Toast.makeText(getApplicationContext(),
                                "Successfully Updated Profile", Toast.LENGTH_LONG).show();
                        // Launch login activity
                        Intent intent = new Intent(
                                UserProfile.this,
                                UserProfile.class);
                        intent.putExtra("uidrandomno", uid);
                        startActivity(intent);
                        finish();
                    } else {
                        setContentView(R.layout.activity_profile);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Registration Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting params to register url
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "userprofile");
                params.put("uid", uidr);
                params.put("blood_group", blood_group);
                params.put("country", country);
                params.put("state", state);
                params.put("district", district);
                params.put("city", city);
                params.put("mobile", mobile);
                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}
