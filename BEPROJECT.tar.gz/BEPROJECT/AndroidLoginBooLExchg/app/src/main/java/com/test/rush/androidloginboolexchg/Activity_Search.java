package com.test.rush.androidloginboolexchg;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;

import java.util.HashMap;
import android.widget.ListView;

import helper.SQLiteHandler;
import helper.SessionManager;

/**
 * Created by root on 14/2/17.
 */

public class Activity_Search extends Activity {
    String[] SPINNERLIST = {"A+", "A-", "B+", "B-","AB+","AB-","O+","O-"};
    private static final String TAG = SQLiteHandler.class.getSimpleName();
    Button btnSearch;
    private ArrayAdapter<String> listAdapter;

    String blood_group;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    //Adding Spinner
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, SPINNERLIST);
       final MaterialBetterSpinner materialDesignSpinner = (MaterialBetterSpinner)
                findViewById(R.id.android_material_design_spinner);
        materialDesignSpinner.setAdapter(arrayAdapter);

        btnSearch = (Button) findViewById(R.id.btnToSearch);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            ListView itemList = (ListView)findViewById(R.id.listView);

            public void onClick(View view) {
                blood_group = materialDesignSpinner.getText().toString();
            searchResult(blood_group);

            }

        }); //search

    } //oncreate

    private void searchResult(String blood_group) {

        
    }

    @Override

    public void onBackPressed() {
        Log.d(TAG, "in backpress method");

        Intent BackpressedIntent = new Intent();
        BackpressedIntent .setClass(getApplicationContext(),Activity_Main.class);
        BackpressedIntent .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(BackpressedIntent );
        finish();

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d(TAG, "Back has been pressed::");
      //  finishActivity(REQ_START_STANDALONE_PLAYER);
        finish();

        Intent i = new Intent(getApplicationContext(),
                Activity_Main.class);
        startActivity(i);


        return true;
    }

}
