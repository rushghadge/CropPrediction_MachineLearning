package com.test.rush.androidloginboolexchg;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import helper.SQLiteHandler;
import volley.AppController;
import volley.Config_URL;

/**
 * Created by root on 21/1/17.
 */

public class Activity_AfterProf_Saving extends Activity {
    private static final String TAG = SQLiteHandler.class.getSimpleName();
    private EditText tv_Country,tv_state,tv_city,tv_bloodgroup,tv_mobile,tv_district;
    public String uidr;
    Button btnUpdateProfile;
    private ProgressDialog pDialog;

    String blood_group,country,state,district,city,mobile;

    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
              uidr= getIntent().getStringExtra("uidrfromLogin");

//            if( getIntent().getStringExtra("uidrfromLogin")!= null)
//            {
//                uidr= getIntent().getStringExtra("uidrandomnofromreg");
//            }
//            else{
//
//                uidr= getIntent().getStringExtra("uidrfromLogin");
//            }
//

            setContentView(R.layout.activity_afterprofsaving);
            btnUpdateProfile = (Button) findViewById(R.id.btnToSaveUserProfile);
        // Progress dialog
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);

            tv_Country = (EditText) findViewById(R.id.edtTxtCountry);
            tv_state = (EditText) findViewById(R.id.edtTxtState);
            tv_city = (EditText) findViewById(R.id.edtTxtCity);
            tv_bloodgroup = (EditText) findViewById(R.id.edtTxtBloodGrp);
            tv_mobile = (EditText) findViewById(R.id.edtTxtMobile);
            tv_district = (EditText) findViewById(R.id.edtTxtDistrict);

            getUserProfileDetails(uidr);


            // Search button Click Event
            btnUpdateProfile.setOnClickListener(new View.OnClickListener() {

                public void onClick(View view) {
                    blood_group=tv_bloodgroup.getText().toString();
                    country = tv_Country.getText().toString();
                    state = tv_state.getText().toString();
                    district= tv_district.getText().toString();
                    city= tv_city.getText().toString();
                    mobile = tv_mobile.getText().toString();
                    Log.d(TAG, "Countru: " + country);
//

                    saveUserProfile(uidr,blood_group,country,state,district,city,mobile);

                }

            }); //search
        }
    private void saveUserProfile(final String uidr,final String blood_group,final String country,final String state,final String district,final String city,final String mobile) {
        // Tag used to cancel the request
        String tag_string_req = "save_prof";
        Log.d(TAG, "Inside Update profile method: ");
        pDialog.setMessage("Updating Profile ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Config_URL.URL_REGISTER, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Update Prof Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    if (!error) {

                        Toast.makeText(getApplicationContext(),
                                "Successfully Updated Profile", Toast.LENGTH_LONG).show();
                        // Launch login activity
                        Intent intent = new Intent(getApplicationContext(),
                                Activity_Main.class);
                        intent.putExtra("uidrandomno", uidr);
                        intent.putExtra("emailuser", uidr);
                        startActivity(intent);
                        finish();
                    } else {
                        setContentView(R.layout.activity_afterprofsaving);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Registration Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                hideDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting params to register url
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "userprofileupdate");
                params.put("uid", uidr);
                params.put("blood_group", blood_group);
                params.put("country", country);
                params.put("state", state);
                params.put("district", district);
                params.put("city", city);
                params.put("mobile", mobile);
                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }


    public void getUserProfileDetails(final String uidr) {
    //   Log.e(TAG, "inside getUserDetails " );
        // Tag used to cancel the request
        String tag_string_req = "reqUserProfile_details";



        StringRequest strReq = new StringRequest(Request.Method.POST,
                Config_URL.URL_REGISTER, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "reqUserProfile_details Response: " + response.toString());
                // hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    boolean error = jObj.getBoolean("error");
                    JSONObject objectuser = jObj.getJSONObject("user");
                    String blood_group = objectuser.getString("blood_group");
                    String country = objectuser.getString("country");
                    String state = objectuser.getString("state");
                    String district = objectuser.getString("district");
                    String city = objectuser.getString("city");
                    String mobile = objectuser.getString("mobile");
                    // JSONObject uidranobj = jObj.getJSONObject("uid");
                    String uidran1 = jObj.getString("uid");
                   String uidran=String.format("%s",uidran1);
                  //  Log.d(TAG, "uid" + uidran);
                    // Check for error node in json
                    if (!error) {

                        tv_Country.setText(country);
                        tv_bloodgroup.setText(blood_group);
                        tv_state.setText(state);
                        tv_city.setText(city);
                        tv_district.setText(district);
                        tv_mobile.setText(mobile);
                        // navname.setText("gfgh");
                    } else {
                        // Error in login. Get the error message
                        String errorMsg = jObj.getString("error_msg");
                        Toast.makeText(getApplicationContext(),
                                errorMsg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
              //  Log.e(TAG, "GetUserDetails Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();
                // hideDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("tag", "getuserprofiledetails");
                params.put("uidr", uidr);


                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
//        startActivity(new Intent(Activity_AfterProf_Saving.this, Activity_Main.class));
//        finish();
        Intent main_activity = new Intent(getApplicationContext(), UserProfile.class);
        main_activity.putExtra("uidrandomno_", uidr);

    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}
