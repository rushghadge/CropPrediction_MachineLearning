-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 12, 2017 at 03:17 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `android_api`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `unique_id` varchar(23) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `encrypted_password` varchar(80) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `unique_id`, `name`, `email`, `encrypted_password`, `salt`, `created_at`, `updated_at`) VALUES
(39, '587618acdb02e4.01524611', 'Ru', 'ru', '+KVewUYbtCygeFhvNxcJAyHKVhtlN2MwMzgzNmIw', 'e7c03836b0', '2017-01-11 17:06:12', NULL),
(40, '587618be797824.07752848', 'Qw', 'qw', 'zLzuA7PC4ASwuhjHUoY5AtXIRfk0YTA0NmRkZTA1', '4a046dde05', '2017-01-11 17:06:30', NULL),
(41, '587619a8d929c4.93919492', 'A', 'a', 'Qiz8p6p7XgZBL2r/MUEbWYGC/OA0YmVhN2NhOWJl', '4bea7ca9be', '2017-01-11 17:10:24', NULL),
(42, '587619e7a0f004.07096570', 'Zx', 'zx', 'd6gZTXBfwy9o+nNS+ea93H0nO6piZmJkZGNiYThm', 'bfbddcba8f', '2017-01-11 17:11:27', NULL),
(43, '587640c0f02579.69574703', 'She', 'she@gmail.c', 'WlBtiVs6OUjlZaHCEQTNvz866/VkNTYwOWM5Zjdk', 'd5609c9f7d', '2017-01-11 19:57:13', NULL),
(44, '587641e126f966.19728192', 'Lol', 'lol@g.com', 'a3Bg3xjvQvy5IqK6QwvmWoiNOngzZjQzYTY1ZDYy', '3f43a65d62', '2017-01-11 20:02:01', NULL),
(45, '58775b5e678481.94339372', 'Rush', 't@t.t', 'm5D/470wYpjYhq3vpKqHqRPSvWMwNWU3OGRjODM4', '05e78dc838', '2017-01-12 16:03:02', NULL),
(46, '58775bee4e2266.19289750', 'pras', 'pras@yahoo.com', 'q+yZzZoO8xbhp8W79Nupv9/d1ZIzZDc3ZTJjNDRm', '3d77e2c44f', '2017-01-12 16:05:26', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `unique_id` (`unique_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
